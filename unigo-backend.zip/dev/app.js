const $=id=>document.getElementById(id);
const show=(id,text,bad=false)=>{const e=$(id);e.textContent=text;e.classList.toggle('error',bad);e.classList.toggle('good',!bad);};
const visible=(id,on)=>$(id).classList.toggle('hidden',!on);
let auth,me=null,studentWatch=null,driverWatch=null,shareTimer=null,findTimer=null,busTimer=null,latestDriver=null,bearing=null,findBusy=false,shareBusy=false,reachedConfirmed=false;
let audioContext=null,lastFeedbackAt=0,lastFeedbackLevel='',previewIndex=0;
let compassActive=false,phoneHeading=null,studentAccuracy=null,driverDisabled=false,authBusy=false;
function onOrientation(event){const heading=Number.isFinite(event.webkitCompassHeading)?event.webkitCompassHeading:event.absolute&&Number.isFinite(event.alpha)?(360-event.alpha)%360:null;if(heading===null)return;phoneHeading=heading;rotate();show('compassStatus','Phone direction active.');}
async function startCompass(){try{if(!window.isSecureContext||!window.DeviceOrientationEvent)throw Error('Phone direction unavailable. Use the map link.');if(typeof DeviceOrientationEvent.requestPermission==='function'&&await DeviceOrientationEvent.requestPermission()!=='granted')throw Error('Phone direction permission denied. Use the map link.');if(!compassActive){window.addEventListener('deviceorientationabsolute',onOrientation);window.addEventListener('deviceorientation',onOrientation);compassActive=true;}show('compassStatus','Waiting for phone direction…');}catch(e){show('compassStatus',e.message,true);}}
async function unlockAudio(){if(!$('soundEnabled').checked)return;try{audioContext??=new (window.AudioContext||window.webkitAudioContext)();if(audioContext.state==='suspended')await audioContext.resume();}catch{show('feedbackStatus','Sound is unavailable in this browser.',true);}}
function tone(start,duration,volume){if(!audioContext||audioContext.state!=='running')return false;const oscillator=audioContext.createOscillator(),gain=audioContext.createGain();oscillator.type='sine';oscillator.frequency.value=520;gain.gain.setValueAtTime(0,start);gain.gain.linearRampToValueAtTime(volume,start+0.015);gain.gain.exponentialRampToValueAtTime(0.001,start+duration);oscillator.connect(gain).connect(audioContext.destination);oscillator.start(start);oscillator.stop(start+duration+0.02);return true;}
function signal(id,level){const e=$(id);e.className=`signal-stage ${level==='VERY_NEAR'?'very-near':level.toLowerCase()}`;}
function feedback(level,preview=false){
  const now=Date.now();if(!preview&&level===lastFeedbackLevel&&now-lastFeedbackAt<1800)return;lastFeedbackAt=now;lastFeedbackLevel=level;
  signal(preview?'previewSignal':'resultSignal',level);
  if(preview)$('previewLabel').textContent=({NEAR:'Getting close',VERY_NEAR:'Very close',FOUND:'Nearby · look around'})[level]||'Far away';
  if(level==='FAR'){show('feedbackStatus','Far: quiet. Feedback starts when you get closer.');return;}
  const pattern=level==='FOUND'?[180,90,180]:level==='VERY_NEAR'?[110,80,110]:[80];
  let sound='off';if($('soundEnabled').checked){const t=audioContext?.currentTime??0;const duration=level==='FOUND'?0.22:level==='VERY_NEAR'?0.16:0.1;const volume=level==='FOUND'?0.12:level==='VERY_NEAR'?0.09:0.06;sound=tone(t,duration,volume)?'playing':'blocked';if(level==='FOUND')tone(t+0.31,0.22,volume);}
  let vibration='off';if($('vibrationEnabled').checked){if(typeof navigator.vibrate==='function'){vibration=navigator.vibrate(pattern)?'requested (device dependent)':'unavailable';}else vibration='unsupported on this browser';}
  show('feedbackStatus',`${preview?'Preview':'Live'}: ${level.replace('_',' ')} · sound ${sound} · vibration ${vibration}.`);
}

async function api(path,body){
  if(!auth?.currentUser)throw Error('Please sign in first.');
  const token=await auth.currentUser.getIdToken();
  const r=await fetch(path,{method:body?'POST':'GET',headers:{Authorization:`Bearer ${token}`,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});
  const data=await r.json();
  if(!r.ok){const code=data.error?.code||'REQUEST_FAILED';throw Error(({ROLE_REQUIRED:'Your Google account has no UniGo role yet. Copy the UID shown above and assign it as a student or driver.',BUS_AWAY:'This bus has not arrived at campus yet.',TOO_FAR:'Move closer to the bus before confirming arrival.',LOCATION_MISSING:'The driver has not shared a location yet.',LOCATION_STALE:'The bus location is too old. Ask the driver to share again.',NOT_ASSIGNED_DRIVER:'This account is not assigned to this bus.',DATA_UNAVAILABLE:'Firebase is not reachable right now.'})[code]||`${code} (${r.status})`);}
  return data;
}
function coord(id){const s=$(id).value.trim();if(!s)throw Error('Enter both latitude and longitude, or use phone location.');return Number(s);}
function locationOnce(){return new Promise((resolve,reject)=>{if(!gpsAllowed())return reject(Error('Live phone GPS is blocked on this HTTP address. Open UniGo through HTTPS, or enter test coordinates below.'));navigator.geolocation.getCurrentPosition(resolve,e=>reject(Error(`Phone location failed: ${e.message}. Check that location permission is on for this browser.`)),{enableHighAccuracy:true,timeout:15000,maximumAge:0});});}
function gpsAllowed(){return window.isSecureContext&&!!navigator.geolocation;}
function setTab(which){visible('studentPanel',which==='student');visible('driverPanel',which==='driver');$('studentTab').classList.toggle('active',which==='student');$('driverTab').classList.toggle('active',which==='driver');}
function rotate(){const arrow=$('arrow');arrow.style.visibility=bearing===null?'hidden':'visible';if(bearing!==null)arrow.style.transform=`rotate(${((bearing-(phoneHeading??0))%360+360)%360}deg)`;}

async function refreshBuses(){
  try{const buses=await api('/api/buses');$('busList').replaceChildren();for(const b of buses){const row=document.createElement('div');row.className='bus';const name=document.createElement('strong');name.textContent=b.id;const detail=document.createElement('div');const status=document.createElement('span');status.className=`pill ${b.live&&b.status==='ARRIVED'?'arrived':'away'}`;status.textContent=!b.lastUpdatedAt?'No driver location yet':!b.live?'Location out of date':b.status==='ARRIVED'?'● Arrived · live':'○ On the way · live';const seen=document.createElement('div');seen.className='fine';seen.textContent=b.lastUpdatedAt?`Last update ${new Date(b.lastUpdatedAt).toLocaleTimeString()}`:'Waiting for driver to share';detail.append(status,seen);row.append(name,detail);$('busList').append(row);}show('busStatus',buses.some(b=>b.live&&b.status==='ARRIVED')?'Choose an arrived bus below.':'Waiting for a driver to share a current location. This list shows real Firebase data.');}
  catch(e){show('busStatus',e.message,true);}
}
async function refreshReachedCount(){if(me?.role!=='driver'||!me.activeBus)return;try{const d=await api(`/api/buses/${me.activeBus}/reached`);$('reachedCount').textContent=d.reachedCount;}catch(e){show('shareStatus',e.message,true);}}
async function loadMe(){
  try{me=await api('/api/me');$('rolePill').textContent=me.role==='driver'?'🚌 Driver':'🎒 Student';$('assignedBus').textContent=me.activeBus||'Not assigned';show('roleHelp',me.role==='driver'?`Your assigned bus is ${me.activeBus||'not set yet'}. Location sharing starts automatically. Keep this page open.`:'Open Student to find an arrived bus.');setTab(me.role==='driver'?'driver':'student');if(me.role==='driver'&&!driverDisabled)startShare();await refreshBuses();await refreshReachedCount();if(busTimer)clearInterval(busTimer);busTimer=setInterval(()=>{refreshBuses();refreshReachedCount();},5000);}
  catch(e){me=null;$('rolePill').textContent='Role not assigned';show('roleHelp',e.message,true);}
}
function stopFind(){if(findTimer)clearInterval(findTimer);findTimer=null;if(studentWatch!==null)navigator.geolocation.clearWatch(studentWatch);studentWatch=null;if(typeof navigator.vibrate==='function')navigator.vibrate(0);show('findStatus','Finding stopped.');}
function stopShare(){if(shareTimer)clearInterval(shareTimer);shareTimer=null;if(driverWatch!==null)navigator.geolocation.clearWatch(driverWatch);driverWatch=null;latestDriver=null;show('shareStatus','Sharing is off.');}
async function find(){if(findBusy)return;findBusy=true;try{
  if(studentAccuracy===null||studentAccuracy>100)throw Error('Waiting for accurate GPS. Go outside and enable precise location.');
  const d=await api(`/api/buses/${$('studentBus').value}/find`,{studentLatitude:coord('studentLat'),studentLongitude:coord('studentLng'),studentAccuracy});
  if(reachedConfirmed)return;
  bearing=d.bearing;rotate();visible('result',true);visible('reachedBus',d.distanceMinMeters<=100);
  $('resultBus').textContent=`${d.busId} · live`;
  $('distance').textContent=d.distanceMeters<1?'GPS gap <1 m':d.distanceMeters<1000?`GPS gap ~${Math.round(d.distanceMeters)} m`:`GPS gap ~${(d.distanceMeters/1000).toFixed(1)} km`;
  $('proximity').textContent=d.locationUncertain?'Could be right beside you':({FAR:'Far away',NEAR:'Getting close',VERY_NEAR:'Very close',FOUND:'Look around'})[d.proximity];
  $('resultNote').textContent=`Possible separation ${d.distanceMinMeters}–${d.distanceMaxMeters} m (GPS accuracy). ${d.locationUncertain?'The phones may be together. The arrow is only a rough hint.':phoneHeading===null?'Arrow is north-up; use the map to orient yourself.':'Arrow follows your phone compass.'} Look for the bus to confirm.`;
  const origin=`${coord('studentLat')},${coord('studentLng')}`,destination=`${d.busLatitude},${d.busLongitude}`;$('mapLink').href=`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}&travelmode=walking`;
  feedback(d.locationUncertain?'FOUND':d.proximity);show('findStatus',`Live · your GPS ±${Math.round(studentAccuracy)} m · bus GPS ±${Math.round(d.busAccuracyMeters??0)} m`);
}catch(e){visible('result',false);show('findStatus',e.message,true);}finally{findBusy=false;}}

async function sendDriver(position){if(shareBusy||driverDisabled)return;shareBusy=true;try{if(position&&Date.now()-position.timestamp>10000)throw Error('Waiting for a fresh GPS fix.');if(position&&(!Number.isFinite(position.coords.accuracy)||position.coords.accuracy>100))throw Error(`GPS is only accurate to ±${Math.round(position.coords.accuracy)} m. Move outside; not sending a misleading location.`);const lat=position?position.coords.latitude:coord('driverLat'),lng=position?position.coords.longitude:coord('driverLng');const body={latitude:lat,longitude:lng};if(position){body.accuracy=position.coords.accuracy;if(Number.isFinite(position.coords.heading))body.heading=position.coords.heading;}$('driverLat').value=lat;$('driverLng').value=lng;const d=await api(`/api/buses/${me?.activeBus||'V12'}/location`,body);$('driverBusState').textContent=d.status==='ARRIVED'?'✅ Arrived at campus':'🚌 On the way';$('driverAccuracy').textContent=position?`GPS ±${Math.round(position.coords.accuracy)} m`:'';show('shareStatus',`Live location sent at ${new Date(d.updatedAt).toLocaleTimeString()}. Keep this page open.`);}
  catch(e){show('shareStatus',e.message,true);}finally{shareBusy=false;}}

$('studentTab').onclick=()=>setTab('student');$('driverTab').onclick=()=>setTab('driver');$('refreshBuses').onclick=refreshBuses;
$('studentGps').onclick=async()=>{try{const p=await locationOnce();$('studentLat').value=p.coords.latitude;$('studentLng').value=p.coords.longitude;studentAccuracy=p.coords.accuracy;show('findStatus',`Your GPS accuracy: ±${Math.round(studentAccuracy)} m.`);}catch(e){show('findStatus',e.message,true);}};
$('find').onclick=async()=>{startCompass();unlockAudio();stopFind();reachedConfirmed=false;visible('result',false);visible('reachedBus',false);visible('reachedStatus',false);lastFeedbackAt=0;try{if(!gpsAllowed())throw Error('Open the HTTPS UniGo link on your phone for live location.');show('findStatus','Getting a precise phone location…');const p=await locationOnce();$('studentLat').value=p.coords.latitude;$('studentLng').value=p.coords.longitude;studentAccuracy=p.coords.accuracy;studentWatch=navigator.geolocation.watchPosition(next=>{$('studentLat').value=next.coords.latitude;$('studentLng').value=next.coords.longitude;studentAccuracy=next.coords.accuracy;find();},e=>show('findStatus',`Location stopped: ${e.message}`,true),{enableHighAccuracy:true,maximumAge:0});await find();findTimer=setInterval(find,3000);}catch(e){show('findStatus',e.message,true);}};
$('stopFind').onclick=stopFind;
$('reachedBus').onclick=async()=>{if($('reachedBus').disabled)return;$('reachedBus').disabled=true;try{if(studentAccuracy===null)throw Error('Waiting for your phone location.');const d=await api(`/api/buses/${$('studentBus').value}/reached`,{studentLatitude:coord('studentLat'),studentLongitude:coord('studentLng'),studentAccuracy});reachedConfirmed=true;stopFind();if(audioContext?.state==='running')audioContext.suspend().catch(()=>{});visible('reachedBus',false);visible('reachedStatus',true);show('reachedStatus',`✓ Reached ${d.busId}. Driver sees ${d.reachedCount} confirmed student${d.reachedCount===1?'':'s'} for this arrival.`);show('findStatus','Reached · tracking stopped.');$('proximity').textContent='Reached';$('resultNote').textContent='Your arrival was sent to the driver count.';}catch(e){show('findStatus',e.message,true);}finally{$('reachedBus').disabled=false;}};
$('testFeedback').onclick=async()=>{await unlockAudio();feedback(['NEAR','VERY_NEAR','FOUND'][previewIndex++%3],true);};
function startShare(){if(driverWatch!==null||driverDisabled)return;if(!me?.activeBus)return show('shareStatus','This driver has no assigned bus yet.',true);if(!gpsAllowed())return show('shareStatus','Live GPS needs the HTTPS link.',true);driverWatch=navigator.geolocation.watchPosition(p=>{latestDriver=p;sendDriver(p);},e=>show('shareStatus',`Location permission needed: ${e.message}`,true),{enableHighAccuracy:true,maximumAge:0});shareTimer=setInterval(()=>{if(latestDriver)sendDriver(latestDriver);},5000);show('shareStatus','Sharing is on. Waiting for precise GPS…');}
$('startShare').onclick=()=>{driverDisabled=false;startShare();};
$('stopShare').onclick=()=>{driverDisabled=true;stopShare();};$('sendOnce').onclick=()=>sendDriver(null);
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&me?.role==='driver')startShare();});

async function init(){
  if(!gpsAllowed()){visible('studentGpsHelp',true);visible('driverGpsHelp',true);}
  const cfg=await fetch('/dev-config').then(r=>r.json()).catch(()=>({}));
  if(!cfg.apiKey){visible('setup',true);$('googleLogin').disabled=true;show('loginStatus','Google login needs the Firebase Web API key in .env.',true);return;}
  try{
    const [{initializeApp},{getAuth,GoogleAuthProvider,signInWithPopup,signInWithEmailAndPassword,getRedirectResult,onAuthStateChanged,signOut}]=await Promise.all([import('https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js'),import('https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js')]);
    auth=getAuth(initializeApp(cfg));
    const provider=new GoogleAuthProvider();
    $('googleLogin').onclick=async()=>{if(authBusy)return;authBusy=true;$('googleLogin').disabled=true;try{show('loginStatus','Opening Google sign-in…');await signInWithPopup(auth,provider);}catch(e){const help=e.code==='auth/unauthorized-domain'?'Add this page’s domain in Firebase Authentication → Settings → Authorized domains.':e.code==='auth/popup-blocked'?'Allow pop-ups for this page, then try again.':e.code==='auth/popup-closed-by-user'?'The Google window closed before sign-in finished. Open UniGo in Chrome or Safari and try again.':e.code==='auth/account-exists-with-different-credential'?'Use the email/password sign-in below for your existing test account.':e.message;show('loginStatus',`${e.code||'Login failed'}: ${help}`,true);}finally{authBusy=false;$('googleLogin').disabled=false;}};
    $('emailLogin').onclick=async()=>{if(authBusy)return;authBusy=true;$('emailLogin').disabled=true;try{show('loginStatus','Signing in…');await signInWithEmailAndPassword(auth,$('email').value,$('password').value);$('password').value='';}catch(e){show('loginStatus',`${e.code||'Login failed'}: ${e.message}`,true);}finally{authBusy=false;$('emailLogin').disabled=false;}};
    $('signOut').onclick=async()=>{stopFind();stopShare();await signOut(auth);};
    await getRedirectResult(auth).catch(e=>show('loginStatus',`${e.code}: ${e.message}`,true));
    onAuthStateChanged(auth,async user=>{visible('loginCard',!user);visible('appCard',!!user);visible('signOut',!!user);$('accountEmail').textContent=user?.email||'';if(user){$('identity').textContent=user.displayName||user.email||'Signed in';$('uid').textContent=user.uid;await loadMe();}else{me=null;if(busTimer)clearInterval(busTimer);busTimer=null;}});
  }catch(e){show('loginStatus',`Could not load Firebase sign-in: ${e.message}`,true);}
}
init();
