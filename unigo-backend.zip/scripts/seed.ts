import 'dotenv/config';
import { FirebaseStore } from '../src/store.js';
const projectId=process.env.FIREBASE_PROJECT_ID,databaseURL=process.env.FIREBASE_DATABASE_URL;
if(!projectId||!databaseURL) throw new Error('Firebase configuration required');
await new FirebaseStore(projectId,databaseURL).seed();
console.log('V12/V13 seeded where absent');
