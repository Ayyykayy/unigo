import 'dotenv/config';
const token=process.env.DRIVER_ID_TOKEN;
const lat=Number(process.env.CAMPUS_LAT),lng=Number(process.env.CAMPUS_LNG);
if(!token||!Number.isFinite(lat)||!Number.isFinite(lng)||!process.env.CAMPUS_LAT||!process.env.CAMPUS_LNG) throw new Error('Set DRIVER_ID_TOKEN, CAMPUS_LAT and CAMPUS_LNG');
const radius=Number(process.env.CAMPUS_RADIUS_METERS||200);
const base=`http://localhost:${process.env.PORT||3000}`;
for(const scale of [3,2,1.1,0.8,0.3]) {
  const latitude=lat+scale*radius/111195;
  const response=await fetch(`${base}/api/buses/V12/location`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({latitude,longitude:lng,accuracy:8,heading:180})});
  console.log(scale, response.status, await response.text());
  if(!response.ok) process.exit(1);
  await new Promise(resolve=>setTimeout(resolve,2000));
}
