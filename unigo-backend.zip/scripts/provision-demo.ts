import 'dotenv/config';
import {getApps,initializeApp,applicationDefault} from 'firebase-admin/app';
import {getAuth} from 'firebase-admin/auth';
import {getDatabase} from 'firebase-admin/database';

const {FIREBASE_PROJECT_ID:projectId,FIREBASE_DATABASE_URL:databaseURL,STUDENT_UID:studentUid,DRIVER_UID:driverUid}=process.env;
if(!projectId||!databaseURL||!studentUid||!driverUid||studentUid===driverUid) throw new Error('Set Firebase project/database and distinct STUDENT_UID, DRIVER_UID');
const app=getApps()[0]??initializeApp({credential:applicationDefault(),projectId,databaseURL});
await Promise.all([getAuth(app).getUser(studentUid),getAuth(app).getUser(driverUid)]);
const db=getDatabase(app);
const [bus,assignment]=await Promise.all([db.ref('buses/V12').get(),db.ref(`drivers/${driverUid}/activeBus`).get()]);
if(!bus.exists()) throw new Error('Run npm run seed first');
if(assignment.exists() && assignment.val()!=='V12') throw new Error('Driver already assigned to another bus');
const oldDriver=bus.child('driverId').val();
const updates:Record<string,unknown>={[`users/${studentUid}/role`]:'student',[`users/${driverUid}/role`]:'driver',[`drivers/${driverUid}/activeBus`]:'V12','buses/V12/driverId':driverUid};
if(typeof oldDriver==='string'&&oldDriver!==driverUid) updates[`drivers/${oldDriver}/activeBus`]=null;
await db.ref().update(updates);
console.log('Demo users and V12 assignment ready');
