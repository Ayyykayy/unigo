import {test} from 'node:test';
import assert from 'node:assert/strict';
import {bearingDegrees,distanceMeters,proximityFor,relativeDirection} from '../src/geo.js';
import {createApp} from '../src/app.js';
import type {Bus,Role,Store} from '../src/store.js';

test('geospatial math and exact boundaries',()=>{
  assert.equal(distanceMeters(0,0,0,0),0);
  assert.ok(Math.abs(distanceMeters(0,0,0,1)-111195)<20);
  assert.equal(bearingDegrees(0,0,0,1),90);
  assert.equal(bearingDegrees(0,0,0,-1),270);
  assert.equal(relativeDirection(10,350),20);
  assert.equal(proximityFor(4.99),'FOUND');
  assert.equal(proximityFor(5),'VERY_NEAR');
  assert.equal(proximityFor(20),'NEAR');
  assert.equal(proximityFor(100),'NEAR');
  assert.equal(proximityFor(100.01),'FAR');
});

class FakeStore implements Store {
  data:Record<string,Bus>={V12:{status:'AWAY',driverId:'d1',location:null},V13:{status:'AWAY',driverId:'d2',location:null}};
  reached=new Set<string>();
  async verify(t:string){if(!['s','d1','d2'].includes(t))throw Error();return t;}
  async role(uid:string):Promise<Role>{return uid==='s'?'student':'driver';}
  async activeBus(uid:string){return uid==='d1'?'V12':uid==='d2'?'V13':null;}
  async buses(){return this.data;}
  async bus(id:string){return this.data[id]??null;}
  async update(id:string,loc:Omit<NonNullable<Bus['location']>,'updatedAt'>,status:Bus['status'],arrivalAt:number|null){const now=Date.now();this.data[id]={...this.data[id],status,arrivalAt:arrivalAt??undefined,location:{...loc,updatedAt:now}};return now;}
  async confirmReached(id:string,arrivalAt:number,uid:string){const key=`${id}/${arrivalAt}/${uid}`,alreadyConfirmed=this.reached.has(key);this.reached.add(key);return {count:await this.reachedCount(id,arrivalAt),alreadyConfirmed};}
  async reachedCount(id:string,arrivalAt:number){return [...this.reached].filter(k=>k.startsWith(`${id}/${arrivalAt}/`)).length;}
  async seed(){}
}
test('authenticated arrival and Find flow',async()=>{
  const store=new FakeStore();
  const server=createApp(store,{campusLat:0,campusLng:0,radius:200,maxAgeSeconds:30,dev:false}).listen(0);
  await new Promise<void>(resolve=>server.once('listening',resolve));
  const addr=server.address();assert.ok(addr&&typeof addr!=='string');
  const base=`http://127.0.0.1:${addr.port}`;
  const call=async(path:string,token:string,body?:object)=>{
    const r=await fetch(base+path,{method:body?'POST':'GET',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});return {code:r.status,data:await r.json()};
  };
  try {
    assert.deepEqual((await fetch(base+'/health').then(r=>r.json())),{ok:true});
    assert.equal((await fetch(base+'/api/buses')).status,401);
    assert.equal((await call('/api/buses','bad')).code,401);
    assert.equal((await call('/api/buses','s')).code,200);
    assert.equal((await call('/api/buses/V12/find','d1',{studentLatitude:0,studentLongitude:0})).code,403);
    assert.equal((await call('/api/buses/V12/location','s',{latitude:0,longitude:0})).code,403);
    assert.equal((await call('/api/buses/V12/location','d2',{latitude:0,longitude:0})).code,403);
    assert.equal((await call('/api/buses/V12/location','d1',{latitude:91,longitude:0})).code,400);
    assert.equal((await call('/api/buses/V12/location','d1',{latitude:0,longitude:0,heading:360})).code,400);
    assert.equal((await fetch(base+'/api/buses/V12/location',{method:'POST',headers:{Authorization:'Bearer d1','Content-Type':'application/json'},body:'{broken'})).status,400);
    assert.equal((await call('/api/buses/V12/find','s',{studentLatitude:0,studentLongitude:0})).data.error.code,'LOCATION_MISSING');
    assert.equal((await call('/api/buses/V12/location','d1',{latitude:0.01,longitude:0})).data.status,'AWAY');
    assert.equal((await call('/api/buses/V12/find','s',{studentLatitude:0,studentLongitude:0})).data.error.code,'BUS_AWAY');
    assert.equal((await call('/api/buses/V12/location','d1',{latitude:0,longitude:0,accuracy:8})).data.status,'ARRIVED');
    for(const [lat,want] of [[0.002,'FAR'],[0.0005,'NEAR'],[0.0001,'VERY_NEAR'],[0,'FOUND']] as const){
      const result=await call('/api/buses/V12/find','s',{studentLatitude:lat,studentLongitude:0});assert.equal(result.data.proximity,want);
    }
    assert.equal((await call('/api/buses/V12/find','s',{studentLatitude:0,studentLongitude:0})).data.locationUncertain,true);
    const nearby=await call('/api/buses/V12/find','s',{studentLatitude:0.000144,studentLongitude:0,studentAccuracy:5});
    assert.ok(nearby.data.distanceMeters>15&&nearby.data.distanceMeters<17);
    assert.equal(nearby.data.locationUncertain,true);
    assert.equal(nearby.data.distanceMinMeters,3);
    assert.equal((await call('/api/buses/V12/reached','s',{studentLatitude:0,studentLongitude:0,studentAccuracy:8})).data.reachedCount,1);
    assert.equal((await call('/api/buses/V12/reached','s',{studentLatitude:0,studentLongitude:0,studentAccuracy:8})).data.alreadyConfirmed,true);
    assert.equal((await call('/api/buses/V12/reached','d1')).data.reachedCount,1);
    assert.equal((await call('/api/buses/V12/reached','s',{studentLatitude:0.1,studentLongitude:0,studentAccuracy:8})).data.error.code,'TOO_FAR');
    await call('/api/buses/V12/location','d1',{latitude:0.01,longitude:0,accuracy:8});
    await call('/api/buses/V12/location','d1',{latitude:0,longitude:0,accuracy:8});
    assert.equal((await call('/api/buses/V12/reached','d1')).data.reachedCount,0);
    store.data.V12.location!.updatedAt=Date.now()-31000;
    assert.equal((await call('/api/buses/V12/find','s',{studentLatitude:0,studentLongitude:0})).data.error.code,'LOCATION_STALE');
  } finally {server.close();}
});
