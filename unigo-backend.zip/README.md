# Run locally

1. `npm install`
2. Copy `.env.example` to `.env`; fill campus and Firebase values. Use Application Default Credentials or a service-account JSON path outside this repository. For local Firebase Emulators, set both emulator hosts listed in `.env.example`.
3. Create Firebase Authentication test users. Put their UIDs in `STUDENT_UID` and `DRIVER_UID` in `.env`. Run `npm run seed` and `npm run provision:demo` to assign the driver to V12. The provision command refuses conflicting assignments. Create another driver for V13 if needed.
4. `npm run dev`; open `http://localhost:3000/dev/`. Supply each user's Firebase ID token in the page. `npm run simulate:v12` uses `DRIVER_ID_TOKEN` from `.env`.

Run `npm run typecheck` and `npm test`. Deploy `database.rules.json` with `npx firebase-tools deploy --only database --project YOUR_PROJECT_ID`; all app data access goes through this backend. To run emulators, install the Firebase CLI and run `npx firebase-tools emulators:start --only auth,database --project YOUR_PROJECT_ID` with emulator hosts in `.env`. Do not expose `/dev` in production (`NODE_ENV=production`). The API uses GPS math and cannot guarantee close-range physical confirmation. Concurrent driver updates may arrive out of order; a production driver client should send a monotonic sequence number if this matters.

## Google login and phone testing

The test page uses `FIREBASE_WEB_API_KEY` in `.env`. In Firebase Console → Authentication → Sign-in method, enable Google. In Authentication → Settings → Authorized domains, add `localhost` for testing on this computer if it is absent. Restart `npm run dev` after changing `.env`. Open `http://localhost:3000/dev/`, sign in, and copy the UID shown under your account. Repeat with the other Google account. Set `STUDENT_UID` and `DRIVER_UID` in `.env`, then run `npm run seed` and `npm run provision:demo`.

The page is responsive on a phone at `http://COMPUTER_IP:3000/dev/` when both devices can reach each other over Wi-Fi. Browser GPS requires HTTPS (or localhost on the same device); plain `http://COMPUTER_IP` permits manual coordinate testing only. Google sign-in from a phone also needs the phone page's domain in Firebase Authorized domains. For a full live phone GPS demo, serve both the page and API from a trusted HTTPS domain. Keep the driver page visible while sharing; browsers pause location work in the background.
