# UniGo API

Base URL: `http://localhost:3000`. Every `/api` request requires `Authorization: Bearer <Firebase ID token>`. Students can list/find; assigned drivers can list/update their bus. JSON errors use `{ "error": { "code": "..." } }` with HTTP 400, 401, 403, 404, 409, or 503.

- `GET /api/buses` → `[{"id":"V12","status":"ARRIVED"}]`
- `POST /api/buses/V12/location` (assigned driver): `{"latitude":12.9712,"longitude":77.5943,"accuracy":8,"heading":120}` → `{"busId":"V12","status":"ARRIVED","updatedAt":1760000000000}`
- `POST /api/buses/V12/find` (student): `{"studentLatitude":12.9710,"studentLongitude":77.5940}` → `{"busId":"V12","status":"ARRIVED","distanceMeters":34.2,"bearing":82.4,"proximity":"NEAR","busLocationUpdatedAt":1760000000000,"busAccuracyMeters":8,"locationUncertain":false}`
- `POST /api/buses/V12/reached` (student): `{"studentLatitude":12.9710,"studentLongitude":77.5940,"studentAccuracy":8}` → `{"busId":"V12","reachedCount":1,"alreadyConfirmed":false}`. Requires a live arrived bus within the GPS-tolerant 100 m range. Repeat confirmation by the same student in the same arrival does not increase the count.
- `GET /api/buses/V12/reached` (assigned driver) → `{"busId":"V12","reachedCount":1}`. The count resets for a new campus arrival.

Find may return `LOCATION_MISSING`, `BUS_AWAY`, or `LOCATION_STALE` with HTTP 409. Bearing is clockwise from true north. `FOUND` is a GPS estimate, not physical confirmation.

Frontend: request student GPS and device heading permissions; rotate the arrow by `(bearing - phoneHeading)` normalized to 0–360; optionally vibrate, play sound, animate proximity, or render a map. Display the GPS-derived distance range and uncertainty. The arrow is only a rough hint when the GPS error circles overlap. The student confirms physical arrival with the reached button.

Backend: verifies Firebase identity and assignment; stores latest bus location; detects arrival; calculates distance, bearing, and proximity.
