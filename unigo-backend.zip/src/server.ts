import 'dotenv/config';
import { createApp, type Config } from './app.js';
import { FirebaseStore } from './store.js';

function numberEnv(name:string, fallback?:number):number {
  const raw=process.env[name];
  if ((raw===undefined||raw==='')&&fallback!==undefined) return fallback;
  const n=Number(raw);
  if (!raw||!Number.isFinite(n)) throw new Error(`${name} must be a finite number`);
  return n;
}
export function configFromEnv():Config {
  const campusLat=numberEnv('CAMPUS_LAT'),campusLng=numberEnv('CAMPUS_LNG');
  if(campusLat< -90||campusLat>90||campusLng< -180||campusLng>180) throw new Error('Invalid campus coordinates');
  const radius=numberEnv('CAMPUS_RADIUS_METERS',200),maxAgeSeconds=numberEnv('LOCATION_MAX_AGE_SECONDS',30);
  if(radius<=0||maxAgeSeconds<=0) throw new Error('Radius and max age must be positive');
  return {campusLat,campusLng,radius,maxAgeSeconds,dev:process.env.NODE_ENV!=='production'};
}
if (process.env.NODE_ENV !== 'test') {
  const config=configFromEnv();
  const projectId=process.env.FIREBASE_PROJECT_ID,databaseURL=process.env.FIREBASE_DATABASE_URL;
  if(!projectId||!databaseURL) throw new Error('FIREBASE_PROJECT_ID and FIREBASE_DATABASE_URL are required');
  const store=new FirebaseStore(projectId,databaseURL);
  const port=numberEnv('PORT',3000);
  createApp(store,config).listen(port,()=>console.log(`UniGo listening on http://localhost:${port}`));
}
