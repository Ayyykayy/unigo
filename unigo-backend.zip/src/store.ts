import { getApps, initializeApp, applicationDefault, type App } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getDatabase, ServerValue } from 'firebase-admin/database';

export type Role = 'student' | 'driver';
export type Bus = { status: 'AWAY' | 'ARRIVED'; driverId: string | null; arrivalAt?:number; location: null | {lat:number;lng:number;accuracy:number|null;heading:number|null;updatedAt:number} };
export interface Store {
  verify(token: string): Promise<string>;
  role(uid: string): Promise<Role | null>;
  activeBus(uid: string): Promise<string | null>;
  buses(): Promise<Record<string, Bus>>;
  bus(id: string): Promise<Bus | null>;
  update(id: string, location: Omit<NonNullable<Bus['location']>, 'updatedAt'>, status: Bus['status'], arrivalAt:number|null): Promise<number>;
  confirmReached(id:string,arrivalAt:number,uid:string):Promise<{count:number;alreadyConfirmed:boolean}>;
  reachedCount(id:string,arrivalAt:number):Promise<number>;
  seed(): Promise<void>;
}
export class FirebaseStore implements Store {
  private app: App;
  constructor(projectId: string, databaseURL: string) {
    this.app = getApps()[0] ?? initializeApp({credential: applicationDefault(), projectId, databaseURL});
  }
  private db() { return getDatabase(this.app); }
  async verify(token: string) { return (await getAuth(this.app).verifyIdToken(token)).uid; }
  async role(uid: string) { const v = (await this.db().ref(`users/${uid}/role`).get()).val(); return v === 'student' || v === 'driver' ? v : null; }
  async activeBus(uid: string) { const v = (await this.db().ref(`drivers/${uid}/activeBus`).get()).val(); return typeof v === 'string' ? v : null; }
  async buses() { return (await this.db().ref('buses').get()).val() ?? {}; }
  async bus(id: string) { return (await this.db().ref(`buses/${id}`).get()).val() ?? null; }
  async update(id: string, location: Omit<NonNullable<Bus['location']>, 'updatedAt'>, status: Bus['status'], arrivalAt:number|null) {
    // One multi-path update keeps status and location in the same database operation.
    await this.db().ref(`buses/${id}`).update({status, arrivalAt, location:{...location,updatedAt:ServerValue.TIMESTAMP}});
    return (await this.db().ref(`buses/${id}/location/updatedAt`).get()).val() as number;
  }
  async confirmReached(id:string,arrivalAt:number,uid:string){
    const ref=this.db().ref(`reached/${id}/${arrivalAt}/${uid}`);
    const result=await ref.transaction(current=>current===null?Date.now():undefined,undefined,false);
    const count=await this.reachedCount(id,arrivalAt);
    return {count,alreadyConfirmed:!result.committed};
  }
  async reachedCount(id:string,arrivalAt:number){return (await this.db().ref(`reached/${id}/${arrivalAt}`).get()).numChildren();}
  async seed() {
    for (const id of ['V12','V13']) {
      const ref = this.db().ref(`buses/${id}`);
      if (!(await ref.get()).exists()) await ref.set({status:'AWAY',driverId:null,location:null});
    }
  }
}
