import express, { type Request, type Response, type NextFunction } from 'express';
import path from 'node:path';
import {readFileSync} from 'node:fs';
import { fileURLToPath } from 'node:url';
import {parse} from 'dotenv';
import { bearingDegrees, distanceMeters, proximityFor, validLat, validLng } from './geo.js';
import type { Role, Store } from './store.js';

export type Config = {campusLat:number;campusLng:number;radius:number;maxAgeSeconds:number;dev:boolean};
type AuthRequest = Request & {uid?:string;role?:Role|null};
const fail = (res: Response, status:number, code:string) => res.status(status).json({error:{code}});
const busIdOK = (id:string) => /^V\d{1,4}$/.test(id);
export function createApp(store:Store, config:Config) {
  const app = express();
  app.use(express.json({limit:'8kb'}));
  app.get('/health', async (_req,res) => {
    try { await store.buses(); res.json({ok:true}); }
    catch { res.status(503).json({ok:false}); }
  });
  if(config.dev) app.get('/',(_req,res)=>res.redirect('/dev/'));
  if (config.dev) app.use('/dev',express.static(path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../dev')));
  if (config.dev) app.get('/dev-config',(_req,res)=>{
    let local:Record<string,string>={};
    try{local=parse(readFileSync('.env'));}catch{}
    const projectId=process.env.FIREBASE_PROJECT_ID||local.FIREBASE_PROJECT_ID||'';
    res.json({apiKey:process.env.FIREBASE_WEB_API_KEY||local.FIREBASE_WEB_API_KEY||'',authDomain:`${projectId}.firebaseapp.com`,projectId});
  });
  const auth = async (req:AuthRequest,res:Response,next:NextFunction) => {
    const token = /^Bearer (.+)$/i.exec(req.header('authorization') ?? '')?.[1];
    if (!token) return fail(res,401,'AUTH_REQUIRED');
    try { req.uid = await store.verify(token); }
    catch { return fail(res,401,'INVALID_TOKEN'); }
    try { req.role = await store.role(req.uid); }
    catch (e) { return next(e); }
    if (!req.role) return fail(res,403,'ROLE_REQUIRED');
    next();
  };
  app.use('/api',auth);
  app.get('/api/me',async(req:AuthRequest,res,next)=>{
    try {res.json({uid:req.uid,role:req.role,activeBus:req.role==='driver'?await store.activeBus(req.uid!):null});}
    catch(e){next(e);}
  });
  app.get('/api/buses',async (_req,res,next) => {
    try { const buses = await store.buses(); res.json(Object.entries(buses).filter(([id])=>busIdOK(id)).map(([id,b])=>({id,status:b.status,lastUpdatedAt:b.location?.updatedAt??null,live:typeof b.location?.updatedAt==='number'&&Date.now()-b.location.updatedAt>=0&&Date.now()-b.location.updatedAt<=config.maxAgeSeconds*1000})).sort((a,b)=>a.id.localeCompare(b.id))); }
    catch(e){next(e);}
  });
  app.post('/api/buses/:busId/location',async (req:AuthRequest,res,next) => {
    try {
      const id=String(req.params.busId);
      if (!busIdOK(id)) return fail(res,400,'INVALID_BUS_ID');
      const {latitude,longitude,accuracy,heading}=req.body ?? {};
      if (!validLat(latitude)||!validLng(longitude)||
          (accuracy!==undefined && (typeof accuracy!=='number'||!Number.isFinite(accuracy)||accuracy<0))||
          (heading!==undefined && (typeof heading!=='number'||!Number.isFinite(heading)||heading<0||heading>=360))) return fail(res,400,'INVALID_LOCATION');
      const bus=await store.bus(id);
      if (!bus) return fail(res,404,'BUS_NOT_FOUND');
      if (req.role!=='driver'||await store.activeBus(req.uid!)!==id||bus.driverId!==req.uid) return fail(res,403,'NOT_ASSIGNED_DRIVER');
      const status=distanceMeters(latitude,longitude,config.campusLat,config.campusLng)<=config.radius?'ARRIVED':'AWAY';
      const arrivalAt=status==='ARRIVED'?(bus.status==='ARRIVED'&&bus.arrivalAt?bus.arrivalAt:Math.max(Date.now(),(bus.arrivalAt??0)+1)):bus.arrivalAt??null;
      const updatedAt=await store.update(id,{lat:latitude,lng:longitude,accuracy:accuracy??null,heading:heading??null},status,arrivalAt);
      res.json({busId:id,status,updatedAt});
    } catch(e){next(e);}
  });
  app.post('/api/buses/:busId/find',async (req:AuthRequest,res,next) => {
    try {
      if (req.role!=='student') return fail(res,403,'STUDENT_REQUIRED');
      const id=String(req.params.busId);
      if (!busIdOK(id)) return fail(res,400,'INVALID_BUS_ID');
      const {studentLatitude,studentLongitude,studentAccuracy}=req.body ?? {};
      if (!validLat(studentLatitude)||!validLng(studentLongitude)) return fail(res,400,'INVALID_LOCATION');
      if (studentAccuracy!==undefined && (typeof studentAccuracy!=='number'||!Number.isFinite(studentAccuracy)||studentAccuracy<0)) return fail(res,400,'INVALID_LOCATION');
      const bus=await store.bus(id);
      if (!bus) return fail(res,404,'BUS_NOT_FOUND');
      if (!bus.location) return fail(res,409,'LOCATION_MISSING');
      if (bus.status!=='ARRIVED') return fail(res,409,'BUS_AWAY');
      const age=Date.now()-bus.location.updatedAt;
      if (!Number.isFinite(age)||age<0||age>config.maxAgeSeconds*1000) return fail(res,409,'LOCATION_STALE');
      const d=distanceMeters(studentLatitude,studentLongitude,bus.location.lat,bus.location.lng);
      const uncertainty=(studentAccuracy??0)+(bus.location.accuracy??0);
      res.json({busId:id,status:bus.status,distanceMeters:Math.round(d*10)/10,distanceMinMeters:Math.max(0,Math.round(d-uncertainty)),distanceMaxMeters:Math.round(d+uncertainty),bearing:Math.round(bearingDegrees(studentLatitude,studentLongitude,bus.location.lat,bus.location.lng)*10)/10,proximity:proximityFor(d),busLatitude:bus.location.lat,busLongitude:bus.location.lng,busLocationUpdatedAt:bus.location.updatedAt,busAccuracyMeters:bus.location.accuracy,uncertaintyMeters:uncertainty,locationUncertain:d<=Math.max(25,uncertainty)});
    } catch(e){next(e);}
  });
  app.post('/api/buses/:busId/reached',async(req:AuthRequest,res,next)=>{
    try{
      if(req.role!=='student')return fail(res,403,'STUDENT_REQUIRED');
      const id=String(req.params.busId);
      if(!busIdOK(id))return fail(res,400,'INVALID_BUS_ID');
      const {studentLatitude,studentLongitude,studentAccuracy}=req.body??{};
      if(!validLat(studentLatitude)||!validLng(studentLongitude)||typeof studentAccuracy!=='number'||!Number.isFinite(studentAccuracy)||studentAccuracy<0||studentAccuracy>100)return fail(res,400,'INVALID_LOCATION');
      const bus=await store.bus(id);
      if(!bus)return fail(res,404,'BUS_NOT_FOUND');
      if(!bus.location||bus.status!=='ARRIVED'||!bus.arrivalAt)return fail(res,409,'BUS_AWAY');
      const age=Date.now()-bus.location.updatedAt;
      if(age<0||age>config.maxAgeSeconds*1000)return fail(res,409,'LOCATION_STALE');
      const distance=distanceMeters(studentLatitude,studentLongitude,bus.location.lat,bus.location.lng);
      if(distance>100+studentAccuracy+(bus.location.accuracy??0))return fail(res,409,'TOO_FAR');
      const result=await store.confirmReached(id,bus.arrivalAt,req.uid!);
      res.json({busId:id,reachedCount:result.count,alreadyConfirmed:result.alreadyConfirmed});
    }catch(e){next(e);}
  });
  app.get('/api/buses/:busId/reached',async(req:AuthRequest,res,next)=>{
    try{
      const id=String(req.params.busId);
      if(!busIdOK(id))return fail(res,400,'INVALID_BUS_ID');
      const bus=await store.bus(id);
      if(!bus)return fail(res,404,'BUS_NOT_FOUND');
      if(req.role!=='driver'||await store.activeBus(req.uid!)!==id||bus.driverId!==req.uid)return fail(res,403,'NOT_ASSIGNED_DRIVER');
      res.json({busId:id,reachedCount:bus.status==='ARRIVED'&&bus.arrivalAt?await store.reachedCount(id,bus.arrivalAt):0});
    }catch(e){next(e);}
  });
  app.use((err:Error & {status?:number},_req:Request,res:Response,_next:NextFunction)=>{
    if(err.status===400) return fail(res,400,'INVALID_JSON');
    console.error(err);return fail(res,503,'DATA_UNAVAILABLE');
  });
  return app;
}
