export type Proximity = 'FAR' | 'NEAR' | 'VERY_NEAR' | 'FOUND';
export const validLat = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v) && v >= -90 && v <= 90;
export const validLng = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v) && v >= -180 && v <= 180;
const rad = (v: number) => v * Math.PI / 180;
export function distanceMeters(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const dLat = rad(bLat - aLat), dLng = rad(bLng - aLng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(aLat)) * Math.cos(rad(bLat)) * Math.sin(dLng / 2) ** 2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0, 1 - h)));
}
export function bearingDegrees(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const dLng = rad(bLng - aLng);
  const y = Math.sin(dLng) * Math.cos(rad(bLat));
  const x = Math.cos(rad(aLat)) * Math.sin(rad(bLat)) - Math.sin(rad(aLat)) * Math.cos(rad(bLat)) * Math.cos(dLng);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}
export function proximityFor(d: number): Proximity {
  return d < 5 ? 'FOUND' : d < 20 ? 'VERY_NEAR' : d <= 100 ? 'NEAR' : 'FAR';
}
export const relativeDirection = (bearing: number, heading: number) => ((bearing - heading) % 360 + 360) % 360;
